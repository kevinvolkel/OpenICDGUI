#pragma once
#include<string>
#include "ICD_sensing_BS_types.h" 



//function to set NSR template structre
void NSR_Temp_Set(std::string EGM_num, struct4_T *NSR_temp);