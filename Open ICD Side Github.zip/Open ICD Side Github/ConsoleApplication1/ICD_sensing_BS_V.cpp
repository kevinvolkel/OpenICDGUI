//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: ICD_sensing_BS_V.cpp
//
// MATLAB Coder version            : 3.0
// C/C++ source code generated on  : 28-Mar-2016 15:53:45
//

// Include Files
#include "rt_nonfinite.h"
#include "ICD_sensing_BS.h"
#include "ICD_sensing_BS_A.h"
#include "ICD_sensing_BS_V.h"
#include "ICD_sensing_init_BS.h"

// Function Definitions

//
// Arguments    : struct0_T *ICD_sense_state
//                struct1_T *ICD_sense_param
//                double *b_signal
//                double *V_in
//                double *A_in
// Return Type  : void
//
void ICD_sensing_BS_V(struct0_T *ICD_sense_state, struct1_T *ICD_sense_param,
                      double *b_signal, double *V_in, double *A_in)
{
  double mtmp;
  double varargin_1_idx_1;
  int ixstart;
  int ix;
  boolean_T exitg1;

  // ICD Sensing Function
  // input: TBD
  //  % parameter struct
  //  (initial settings)
  // ICD_sense_state
  // State: 1 - sensing/AGC
  //        2 - peak tracking
  //        3 - absolute blanking
  //        4 - noise window
  //        5 - fixed refractory
  //  ICD_sense_state.State=1;
  //  ICD_sense_state.VPace=0;
  //  ICD_sense_state.VSense=0;
  //  ICD_sense_state.APace=0;
  //  ICD_sense_state.ASense=0;
  //  ICD_sense_state.StateClock=0;
  //  ICD_sense_state.StateClockLim=0;
  //  ICD_sense_state.RefPeriodClock=0;
  //  ICD_sense_state.VThres=vThresMin;
  //  ICD_sense_state.VType=1;
  //  ICD_sense_state.VAvg=vThresMin;%TODO: could be different initial value
  //  ICD_sense_state.DebugClock=0;
  //  current state
  //  current waveform sample (vector)
  // output: TBD
  //  input waveform
  //  current threshold
  // TODO: what happens when there is a VPACE event, but it is not sensed?
  *V_in = 0.0;
  *A_in = 0.0;
  *b_signal = fabs(*b_signal);
  ICD_sense_state->DebugClock++;
  ICD_sense_param->DebugClock++;

  // AGC
  if (ICD_sense_state->VState == 1.0) {
    if (*b_signal >= ICD_sense_state->VThres) {
      ICD_sense_state->VState = 2.0;
      ICD_sense_state->VStateClock = 0.0;
      ICD_sense_state->VStateClockLim = ICD_sense_param->VAbsBlankPeriod;
      ICD_sense_state->VAGCOn = 0.0;
      if (ICD_sense_state->VPace == 0.0) {
        ICD_sense_state->VSense = 1.0;
        *V_in = 1.0;
      }

      if (ICD_sense_state->VPace == 0.0) {
        ICD_sense_state->VType = 1.0;
      } else {
        ICD_sense_state->VType = 2.0;
      }
    } else {
      ICD_sense_state->VStateClock++;
    }

    // PeakTracking
  } else if (ICD_sense_state->VState == 2.0) {
    ICD_sense_state->VStateClock++;

    //      if(ICD_sense_state.VSense==1)%TODO: Does this need to be here?
    //          ICD_sense_state.VSense=0;
    //      end
    if (*b_signal < ICD_sense_state->VThres) {
      ICD_sense_state->VStateClock = 0.0;
      ICD_sense_state->VStateClockLim = ICD_sense_param->VAbsBlankPeriod;
      ICD_sense_state->VState = 3.0;

      // update peak
      // ICD_sense_state.VAvg=ICD_sense_state.VAvg*(3/4)+signal*(1/4);
      ICD_sense_state->VAvg = ICD_sense_state->VAvg * 0.75 +
        ICD_sense_state->VThres * 0.25;
      ICD_sense_state->PrevV = ICD_sense_state->VThres;
      mtmp = ICD_sense_state->VAvg * 0.125;
      varargin_1_idx_1 = ICD_sense_param->VAGCNomThres;
      ixstart = 1;
      if (rtIsNaN(mtmp)) {
        ix = 2;
        exitg1 = false;
        while ((!exitg1) && (ix < 3)) {
          ixstart = 2;
          if (!rtIsNaN(varargin_1_idx_1)) {
            mtmp = varargin_1_idx_1;
            exitg1 = true;
          } else {
            ix = 3;
          }
        }
      }

      if ((ixstart < 2) && (varargin_1_idx_1 > mtmp)) {
        mtmp = varargin_1_idx_1;
      }

      ICD_sense_state->VThresMin = mtmp;
      ICD_sense_state->VThresMax = ICD_sense_state->VAvg * 1.5;
    } else {
      // while peak is going up
      ICD_sense_state->VThres = *b_signal;
    }

    // AbsoluteBlanking
  } else if (ICD_sense_state->VState == 3.0) {
    if (ICD_sense_state->VStateClock >= ICD_sense_state->VStateClockLim) {
      ICD_sense_state->VStateClock = 0.0;
      ICD_sense_state->VStateClockLim = ICD_sense_param->VNoiseWindow;

      // ICD_sense_state.VThres=ICD_sense_state.VThres*.75;
      ICD_sense_state->VState = 4.0;
    } else {
      ICD_sense_state->VStateClock++;
    }

    // Noise window
  } else if (ICD_sense_state->VState == 4.0) {
    if (ICD_sense_state->VStateClock >= ICD_sense_state->VStateClockLim) {
      ICD_sense_state->VStateClock = 0.0;
      ICD_sense_state->VStateClockLim = ICD_sense_param->VFixedRefPeriod;
      ICD_sense_state->VState = 5.0;
    } else {
      // TODO: something to repeat noise window is noise detected
      ICD_sense_state->VStateClock++;
    }

    // Fixed Refractory
  } else {
    if (ICD_sense_state->VState == 5.0) {
      if (ICD_sense_state->VStateClock >= ICD_sense_state->VStateClockLim) {
        ICD_sense_state->VThres *= 0.75;
        ICD_sense_state->VStateClock = 0.0;
        ICD_sense_state->VStateClockLim = ICD_sense_param->VFixedRefPeriod;
        ICD_sense_state->VState = 1.0;
        ICD_sense_state->VAGCOn = 1.0;
        ICD_sense_state->VAGCClock = 0.0;

        // V_in=1;
      } else {
        // TODO: something to during fixed refractory
        ICD_sense_state->VStateClock++;
      }
    }
  }

  // AGC
  if (ICD_sense_state->VAGCOn == 1.0) {
    ICD_sense_state->VAGCClock++;
    if (ICD_sense_state->VAGCClock >= ICD_sense_state->VAGCClockLim) {
      // check if minimum threshold
      ICD_sense_state->VAGCClock = 0.0;
      ICD_sense_state->VThres *= 0.875;
      if (ICD_sense_state->VThres <= ICD_sense_state->VThresMin) {
        ICD_sense_state->VThres = ICD_sense_state->VThresMin;
      }

      // if(ICD_sense_state.VThres<ICD_sense_param.VThresMin)
      //     ICD_sense_state.VThres=ICD_sense_param.VThresMin;
      // end
    }
  }
}

//
// Arguments    : struct0_T *ICD_sense_state
//                struct1_T *ICD_sense_param
//                double *b_signal
// Return Type  : double
//
double b_ICD_sensing_BS_V(struct0_T *ICD_sense_state, struct1_T *ICD_sense_param,
  double *b_signal)
{
  double V_in;
  double mtmp;
  double varargin_1_idx_1;
  int ixstart;
  int ix;
  boolean_T exitg1;

  // ICD Sensing Function
  // input: TBD
  //  % parameter struct
  //  (initial settings)
  // ICD_sense_state
  // State: 1 - sensing/AGC
  //        2 - peak tracking
  //        3 - absolute blanking
  //        4 - noise window
  //        5 - fixed refractory
  //  ICD_sense_state.State=1;
  //  ICD_sense_state.VPace=0;
  //  ICD_sense_state.VSense=0;
  //  ICD_sense_state.APace=0;
  //  ICD_sense_state.ASense=0;
  //  ICD_sense_state.StateClock=0;
  //  ICD_sense_state.StateClockLim=0;
  //  ICD_sense_state.RefPeriodClock=0;
  //  ICD_sense_state.VThres=vThresMin;
  //  ICD_sense_state.VType=1;
  //  ICD_sense_state.VAvg=vThresMin;%TODO: could be different initial value
  //  ICD_sense_state.DebugClock=0;
  //  current state
  //  current waveform sample (vector)
  // output: TBD
  //  input waveform
  //  current threshold
  // TODO: what happens when there is a VPACE event, but it is not sensed?
  V_in = 0.0;
  *b_signal = fabs(*b_signal);
  ICD_sense_state->DebugClock++;
  ICD_sense_param->DebugClock++;

  // AGC
  if (ICD_sense_state->VState == 1.0) {
    if (*b_signal >= ICD_sense_state->VThres) {
      ICD_sense_state->VState = 2.0;
      ICD_sense_state->VStateClock = 0.0;
      ICD_sense_state->VStateClockLim = ICD_sense_param->VAbsBlankPeriod;
      ICD_sense_state->VAGCOn = 0.0;
      if (ICD_sense_state->VPace == 0.0) {
        ICD_sense_state->VSense = 1.0;
        V_in = 1.0;
      }

      if (ICD_sense_state->VPace == 0.0) {
        ICD_sense_state->VType = 1.0;
      } else {
        ICD_sense_state->VType = 2.0;
      }
    } else {
      ICD_sense_state->VStateClock++;
    }

    // PeakTracking
  } else if (ICD_sense_state->VState == 2.0) {
    ICD_sense_state->VStateClock++;

    //      if(ICD_sense_state.VSense==1)%TODO: Does this need to be here?
    //          ICD_sense_state.VSense=0;
    //      end
    if (*b_signal < ICD_sense_state->VThres) {
      ICD_sense_state->VStateClock = 0.0;
      ICD_sense_state->VStateClockLim = ICD_sense_param->VAbsBlankPeriod;
      ICD_sense_state->VState = 3.0;

      // update peak
      // ICD_sense_state.VAvg=ICD_sense_state.VAvg*(3/4)+signal*(1/4);
      ICD_sense_state->VAvg = ICD_sense_state->VAvg * 0.75 +
        ICD_sense_state->VThres * 0.25;
      ICD_sense_state->PrevV = ICD_sense_state->VThres;
      mtmp = ICD_sense_state->VAvg * 0.125;
      varargin_1_idx_1 = ICD_sense_param->VAGCNomThres;
      ixstart = 1;
      if (rtIsNaN(mtmp)) {
        ix = 2;
        exitg1 = false;
        while ((!exitg1) && (ix < 3)) {
          ixstart = 2;
          if (!rtIsNaN(varargin_1_idx_1)) {
            mtmp = varargin_1_idx_1;
            exitg1 = true;
          } else {
            ix = 3;
          }
        }
      }

      if ((ixstart < 2) && (varargin_1_idx_1 > mtmp)) {
        mtmp = varargin_1_idx_1;
      }

      ICD_sense_state->VThresMin = mtmp;
      ICD_sense_state->VThresMax = ICD_sense_state->VAvg * 1.5;
    } else {
      // while peak is going up
      ICD_sense_state->VThres = *b_signal;
    }

    // AbsoluteBlanking
  } else if (ICD_sense_state->VState == 3.0) {
    if (ICD_sense_state->VStateClock >= ICD_sense_state->VStateClockLim) {
      ICD_sense_state->VStateClock = 0.0;
      ICD_sense_state->VStateClockLim = ICD_sense_param->VNoiseWindow;

      // ICD_sense_state.VThres=ICD_sense_state.VThres*.75;
      ICD_sense_state->VState = 4.0;
    } else {
      ICD_sense_state->VStateClock++;
    }

    // Noise window
  } else if (ICD_sense_state->VState == 4.0) {
    if (ICD_sense_state->VStateClock >= ICD_sense_state->VStateClockLim) {
      ICD_sense_state->VStateClock = 0.0;
      ICD_sense_state->VStateClockLim = ICD_sense_param->VFixedRefPeriod;
      ICD_sense_state->VState = 5.0;
    } else {
      // TODO: something to repeat noise window is noise detected
      ICD_sense_state->VStateClock++;
    }

    // Fixed Refractory
  } else {
    if (ICD_sense_state->VState == 5.0) {
      if (ICD_sense_state->VStateClock >= ICD_sense_state->VStateClockLim) {
        ICD_sense_state->VThres *= 0.75;
        ICD_sense_state->VStateClock = 0.0;
        ICD_sense_state->VStateClockLim = ICD_sense_param->VFixedRefPeriod;
        ICD_sense_state->VState = 1.0;
        ICD_sense_state->VAGCOn = 1.0;
        ICD_sense_state->VAGCClock = 0.0;

        // V_in=1;
      } else {
        // TODO: something to during fixed refractory
        ICD_sense_state->VStateClock++;
      }
    }
  }

  // AGC
  if (ICD_sense_state->VAGCOn == 1.0) {
    ICD_sense_state->VAGCClock++;
    if (ICD_sense_state->VAGCClock >= ICD_sense_state->VAGCClockLim) {
      // check if minimum threshold
      ICD_sense_state->VAGCClock = 0.0;
      ICD_sense_state->VThres *= 0.875;
      if (ICD_sense_state->VThres <= ICD_sense_state->VThresMin) {
        ICD_sense_state->VThres = ICD_sense_state->VThresMin;
      }

      // if(ICD_sense_state.VThres<ICD_sense_param.VThresMin)
      //     ICD_sense_state.VThres=ICD_sense_param.VThresMin;
      // end
    }
  }

  return V_in;
}

//
// File trailer for ICD_sensing_BS_V.cpp
//
// [EOF]
//
