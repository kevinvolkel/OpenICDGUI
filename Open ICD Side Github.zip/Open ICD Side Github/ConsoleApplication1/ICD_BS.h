//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: ICD_BS.h
//
// MATLAB Coder version            : 3.0
// C/C++ source code generated on  : 05-Apr-2016 15:21:22
//
#ifndef __ICD_BS_H__
#define __ICD_BS_H__

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "ICD_sensing_BS_types.h"

// Function Declarations
extern void ICD_BS(struct4_T *ICD_state, const struct2_T *ICD_param, double
                   A_sense, double V_sense, double V_shock, double *therapy,
                   double *inhibit);

#endif

//
// File trailer for ICD_BS.h
//
// [EOF]
//
