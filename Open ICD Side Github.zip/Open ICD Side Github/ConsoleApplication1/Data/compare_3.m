clear all 
close all

or = importdata('EGM1-1-3.txt');
acq = importdata('output.out3');
event = importdata('Event1-1-3.txt');
decisions = importdata('decisions1-1-3.txt');

asense = event(1:end,1);
vsense  = event(1:end,2);
shock  = event(1:end,3);

or_ventr = or(1:end,2);
or_atrial = or(1:end,1);
or_shock = or(1:end,3);

aq_time =  acq.data(1:end,1);
aq_ventr = acq.data(1:end,3);
aq_atrial = acq.data(1:end,2);
aq_shock = acq.data(1:end,4);
aq_vinput = acq.data(1:end,5);
aq_ainput  = acq.data(1:end,6);
aq_theraphy = acq.data(1:end,7);
aq_inhibit  = acq.data(1:end,8);

theraphy_or = decisions(1:end,1);
inhibit_or  =decisions(1:end,2);
index_delay = find(aq_atrial<-0.2,1);
delay = - index_delay*0.001 + 0.16 ;

delay = - 2.154;
index_delay =  2.154/0.001; 

time_or = linspace(0,30,30000/5);
time_acq = aq_time * 0.001;

or_ventr2=or_ventr(1:5:length(or_ventr));
or_atrial2=or_atrial(1:5:length(or_atrial));
or_shock2=or_shock(1:5:length(or_shock));


figure
plot(time_or,or_atrial2)
hold on 
plot(time_acq,aq_atrial,'r')

figure
plot(time_or,or_atrial2)
hold on 
plot(time_acq+delay,aq_atrial,'r')


figure
plot(time_or,or_ventr2)
hold on 
plot(time_acq+delay,aq_ventr,'r')


figure
plot(time_or,or_shock2)
hold on 
plot(time_acq+delay,aq_shock,'r')

figure
plot(vsense)
hold on 
plot(aq_vinput(index_delay:end),'r');


figure
plot(asense)
hold on 
plot(aq_ainput(index_delay:end),'r');


figure
plot(theraphy_or)
hold on 
plot(aq_theraphy(index_delay:end),'r');

figure
plot(inhibit_or)
hold on 
plot(aq_inhibit(index_delay:end),'r');


lol = 0;
