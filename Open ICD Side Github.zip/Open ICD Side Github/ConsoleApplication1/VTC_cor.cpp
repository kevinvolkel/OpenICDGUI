//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: VTC_cor.cpp
//
// MATLAB Coder version            : 3.0
// C/C++ source code generated on  : 05-Apr-2016 15:21:22
//

// Include Files
#include "rt_nonfinite.h"
#include "ICD_BS.h"
#include "VTC_cor.h"
#include "dis_AFib.h"
#include "dis_STB.h"
#include "dis_VTC.h"
#include "dis_VgtA.h"

// Function Definitions

//
// Arguments    : const double VTC_morph[200]
//                const struct1_T *NSR_temp
//                double *V_morph
//                double *fcc
// Return Type  : void
//
void VTC_cor(const double VTC_morph[200], const struct3_T *NSR_temp, double
             *V_morph, double *fcc)
{
  double x[8];
  int k;
  double y;
  double b_y;
  double c_y;
  double a;
  double d_y;
  for (k = 0; k < 8; k++) {
    x[k] = NSR_temp->refy[k] * VTC_morph[(int)NSR_temp->refx[k] - 1];
  }

  y = x[0];
  b_y = NSR_temp->refy[0];
  c_y = VTC_morph[(int)NSR_temp->refx[0] - 1];
  for (k = 0; k < 7; k++) {
    y += x[k + 1];
    b_y += NSR_temp->refy[k + 1];
    c_y += VTC_morph[(int)NSR_temp->refx[k + 1] - 1];
  }

  a = 8.0 * y - b_y * c_y;
  for (k = 0; k < 8; k++) {
    x[k] = NSR_temp->refy[k] * NSR_temp->refy[k];
  }

  y = x[0];
  b_y = NSR_temp->refy[0];
  for (k = 0; k < 7; k++) {
    y += x[k + 1];
    b_y += NSR_temp->refy[k + 1];
  }

  for (k = 0; k < 8; k++) {
    x[k] = VTC_morph[(int)NSR_temp->refx[k] - 1] * VTC_morph[(int)NSR_temp->
      refx[k] - 1];
  }

  c_y = x[0];
  d_y = VTC_morph[(int)NSR_temp->refx[0] - 1];
  for (k = 0; k < 7; k++) {
    c_y += x[k + 1];
    d_y += VTC_morph[(int)NSR_temp->refx[k + 1] - 1];
  }

  *fcc = a * a / ((8.0 * y - b_y * b_y) * (8.0 * c_y - d_y * d_y));
  if (*fcc >= 0.94) {
    *V_morph = 1.0;
  } else {
    *V_morph = 2.0;
  }

  //  subplot(2,1,1)
  //  gcf;
  //  plot(NSR_temp.raw)
  //  hold on;
  //  %subplot(2,1,2)
  //  plot(VTC_morph,'color','red')
  //  hold off;
  //  1;
}

//
// File trailer for VTC_cor.cpp
//
// [EOF]
//
